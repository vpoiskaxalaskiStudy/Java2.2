package tags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;

public class CustomTag extends TagSupport {

    public String question = "";
    public String name = "un";

    public void setQuestion(String question) { this.question = question; }
    public String getQuestion() { return this.question; }

    public void setName(String name) { this.name = name; }
    public String getName() { return this.name; }

    @Override
    public int doStartTag() throws JspException {
        JspWriter jspWriter = pageContext.getOut();
        try {
            jspWriter.println(question + "<br><input type=\"radio\" name=\"" + name + "\" content=\"Да\" value=\"1\"/>Да<input type=\"radio\" name=\"" + name + "\" content=\"Нет\" value=\"0\"/>Нет<br>");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return super.doStartTag();
    }
}
