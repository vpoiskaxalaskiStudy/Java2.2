import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;

@WebServlet("/QuizServlet")
public class QuizServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        String summerRes = req.getParameter("summer");
        String morningRes = req.getParameter("morning");
        int res = 0;
        int month = Calendar.getInstance().getTime().getMonth();
        int hours = Calendar.getInstance().getTime().getHours();
        if (summerRes.equals("1") && month >= 5 && month <= 7) {
            res += 5;
        }
        if (morningRes.equals("1") && hours >= 6 && hours <= 13) {
            res += 5;
        }
        PrintWriter printWriter = resp.getWriter();
        printWriter.println(res);
        Cookie[] cookies = req.getCookies();
        if (cookies.length > 0)
        {
            for (int i = 0; i < cookies.length; i++)
            {
                if (cookies[i].getName().equals("res")) {
                    printWriter.println("<br><b>Last RESULT:</b>" + cookies[i].getValue());
                    cookies[i].setMaxAge(0);
                }
            }
        }

        Cookie cookie = new Cookie("res", Integer.toString(res));
        cookie.setMaxAge(10000000);
        resp.addCookie(cookie);
    }
}
