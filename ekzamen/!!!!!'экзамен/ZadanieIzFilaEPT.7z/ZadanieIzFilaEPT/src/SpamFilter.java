import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebFilter(servletNames = "QuizServlet")
public class SpamFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletResponse resp = (HttpServletResponse)servletResponse;
        //HttpServletRequest req = (HttpServletRequest) servletRequest;
        String summerRes = servletRequest.getParameter("summer");
        String morningRes = servletRequest.getParameter("morning");
        if ((!summerRes.equals("1") ^ !summerRes.equals("0")) && (!morningRes.equals("1") ^ !morningRes.equals("0"))) {
            resp.sendRedirect("index.jsp");
        }
        else
            filterChain.doFilter(servletRequest, servletResponse);
    }
}
